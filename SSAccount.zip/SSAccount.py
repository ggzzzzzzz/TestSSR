# coding=UTF-8
import urllib2
import re
import os
import subprocess
import base64
import json
import time
import socks
import socket
import shutil

#下载文件
def downloadfile(url, filename):
    print("downloading " + url + "...")
    data = urllib2.urlopen(url)
    with open(filename, "wb") as img:
        img.write(data.read())
    print("done")
#下载shadowsocks.net网页中所有二维码
def downloadallqrcode():
    #s = urllib2.urlopen("https://www.shadowsocks.net/get").read()
    #pattern = re.compile(r"window.open\('media/qr/(.*?)'")  #正则表达式匹配
    #it = re.finditer(pattern, s)
    qrlist = []
    #for match in it:
    #    qrlist.append(match.group(1))
    qrlist.append("jp01.png")
    qrlist.append("jp02.png")
    qrlist.append("jp03.png")
    qrlist.append("us01.png")
    qrlist.append("us02.png")
    qrlist.append("us03.png")

    #qrprefix = r"https://www.shadowsocks.net/media/qr/"
    qrprefix = r"http://freess.org/images/servers/"
    for qrname in qrlist:
        downloadfile(qrprefix + qrname, "qrcode/"+qrname)
#把所有二维码解析为JSON格式的字符串
def parseallqrcode():
    filelist = os.listdir("qrcode")
    sslist = []
    for filename in filelist:
        #使用zbar这个命令行工具解析二维码
        cmd = ["zbar/zbarimg.exe","-D","qrcode/"+filename]
        #使用subprocess~可以获取控制台输出
        output = subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE).communicate()[0]
        print filename+"-->"+output.rstrip()
        index = output.find("ss://")
        if index != -1:
            ss64 = output[index+5:].rstrip()
            #base64解码
            missing_padding = 4 - len(ss64) % 4
            if missing_padding:
                ss64 += b'='* missing_padding
            ss = base64.decodestring(ss64)
            print ss
            #分割字符串 获取配置信息
            pattern = re.compile(r"(?P<method>.*?):(?P<password>.*?)@(?P<ip>((?:(2[0-4]\d)|(25[0-5])|([01]?\d\d?))\.){3}(?:(2[0-4]\d)|(255[0-5])|([01]?\d\d?))):(?P<port>.*)")
            match = re.match(pattern, ss.replace(" ",""))
            if match:
                smethod = match.group("method")
                spassword = match.group("password")
                sserver = match.group("ip")
                sserver_port = match.group("port")
                #转换成JSON格式字符串
                d = dict(server=sserver,server_port=int(sserver_port),password=spassword,method=smethod,local_port=1080,timeout=600)            
                jsonstring = json.dumps(d)
                print jsonstring
                sslist.append(jsonstring)
                
    return sslist # parseallqrcode()
#测试某个访问某个url的延迟 默认最大为5s
def getlatency(url):
    print ("test the latency of "+url+"...")
    start = time.time()
    try:
        r = urllib2.urlopen(url,timeout=5)
    except:
        print ("this socks proxy may be invalid")
        return 5
    end = time.time()
    print r.read()
    latency = end - start
    print ("the latency of "+url+" is "+str(latency))
    return latency
#获取平均延迟 一般>=5s就可以认为这个代理无效
def getaveragelatency():
    urls=["https://www.google.com","https://twitter.com"]
    latencysum = 0
    for url in urls:
        latencysum += getlatency(url)
    averagelatency = latencysum/len(urls)
    print("the average latency is "+str(averagelatency))
    return averagelatency
#获取可用代理 并加上它们的延迟信息
def getavailableproxy():
    sslist = parseallqrcode()
    availables = []
    for ss in sslist:
        print "Testing "+ss+"..."
        #设置config.json文件
        f = open("shadowsocks/config.json","w")
        f.write(ss)
        f.close()
        #启动shadowsocks代理程序
        cmd = ["shadowsocks/shadowsocks-local.exe","-c","shadowsocks/config.json"]
        p = subprocess.Popen(cmd)
        time.sleep(0.5)
        a = getaveragelatency()
        #平均延迟小于5s则认为该代理有效 并加上延迟信息
        if a < 5:
            availables.append("latency:"+str(a)+"--->"+ss)
        p.kill()
        time.sleep(0.5)
    return availables

def create_connection(address, timeout=None, source_address=None):
    sock = socks.socksocket()
    sock.connect(address)
    return sock
#begin
if os.path.exists("qrcode") is not True:
    os.mkdir("qrcode")
downloadallqrcode()
#设置代理
socks.setdefaultproxy(socks.PROXY_TYPE_SOCKS5, "127.0.0.1", 1080)
socket.socket = socks.socksocket
socket.create_connection = create_connection
socket.setdefaulttimeout(5) #设置超时
#获取可用代理并写入到文件
availables = getavailableproxy() # parseallqrcode() -> config.json -> getaveragelatency()
ws = "\r\n".join(availables)
f = open("available.txt","w")
f.write(ws)
f.close()
print ws
#删除二维码文件
shutil.rmtree("qrcode")